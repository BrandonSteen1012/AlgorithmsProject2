// ParallelStudy.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


#include <cctype>
#include <algorithm>
#include <execution>
#include <iostream>
#include <vector>
#include <execution>
#include <chrono>
#include <ppl.h>
#include <random>
#include <concurrent_vector.h>


// Template for dumping a vector:
// https://stackoverflow.com/questions/4077609/overloading-output-stream-operator-for-vectort

template < class T >
std::ostream& operator << (std::ostream& os, typename const std::vector<T>& v)
{
    os << "[ ";
    for (typename std::vector<T>::const_iterator ii = v.begin(); ii != v.end(); ++ii)
    {
        os << " " << *ii;
    }
    os << "]";
    return os;
}


inline unsigned int Find_Split_Point(concurrency::concurrent_vector<int>& A, const unsigned int p, const unsigned int r,const int x) {
    auto low = p;
    auto high = r + 1;
 //   std::cout << "Split" << p << "," << r << "," << x << std::endl;
    while (low < high) {
        auto mid = (low + high) >> 1;
        if (x <= A[mid]) high = mid;
        else low = mid + 1;
    }
    return low;
}

void P_Merge_AUX(concurrency::concurrent_vector<int>& A,
       int p1,     int r1,
        int p2,     int r2,
    concurrency::concurrent_vector<int>& B,
    const   int p3, const   int B_offset)
{
    
    if ((p1 > r1) && (p2 > r2)) return;
    if ((r1 - p1) < (r2 - p2)) {
        std::swap(p1, p2);
        std::swap(r1, r2);
    }
    auto q1 = (p1 + r1) >> 1;
    auto x = A[q1];
    auto q2 = Find_Split_Point(A, p2, r2,x);
    auto q3 = p3 + (q1 - p1) + (q2 - p2);
    B[q3-B_offset] = x;
  
    auto F1 = [&A, p1, q1, p2, q2, &B, p3, B_offset] {P_Merge_AUX(A, p1, q1 - 1, p2, q2 - 1, B, p3, B_offset);};
    auto F2 = [&A, q1, r1, q2, r2, &B, q3, B_offset] {P_Merge_AUX(A, q1+1,r1, q2, r2, B, q3+1, B_offset);};
    concurrency::parallel_invoke(F1, F2);
   
}

void merge(concurrency::concurrent_vector<int>& A, const unsigned int p, const unsigned int q, const unsigned int r) {
    // we assume that p q and r are never negative, but if r becomes -1 which is make unsigned int watch for it!!
    // see page 36 of CLRS
    auto n_l = q - p + 1;
    auto n_r = r - q;

    //  std::vector<int>  L(&A[p], &A[ p+ n_l - 1]+1);
    //  std::vector<int>  R(&A[q + 1], &A[q + n_r] + 1);
    // concurrent_vectors come with some overhead, but insures non-overlapping access
    // might not be needed, since the accesses should be disjoint.
    concurrency::concurrent_vector<int>  L(&A[p], &A[p + n_l - 1] + 1);
    concurrency::concurrent_vector<int>  R(&A[q + 1], &A[q + n_r] + 1);

    unsigned int i = 0;unsigned int j = 0;unsigned int k = p;
   
    while ((i < n_l) && (j < n_r))
        A[k++] = (L[i] <= R[j]) ? L[i++] : R[j++];

    for (;i < n_l;) A[k++] = L[i++];
    for (;j < n_r;) A[k++] = R[j++];
}

void P_merge(concurrency::concurrent_vector<int>& A, const unsigned int p, const unsigned int q, const unsigned int r) {
    
    if ((r - p) < (2<<12)) {
        merge(A, p, q, r);
        return;
    }
    concurrency::concurrent_vector<int> B(r - p + 1);  
    // This is an allocation of new memory which will slow things down
 
    P_Merge_AUX(A, p, q, q + 1, r, B, p, p);
  
    concurrency::parallel_for(p, r+1, [&A, &B, p](int k) {A[k] = B[k - p];});

}

//void merge_sort(std::vector<int>& A, const unsigned int p, const unsigned int r) {
void merge_sort(concurrency::concurrent_vector<int>& A, const unsigned int p, const unsigned int r) {
    // page 39 CLRS
    if (p >= r) return;
    if ((r - p) < 128) {
        std::sort(&A[p], &A[r]);
        return;
    }
    auto q = (p + r) >> 1;
    merge_sort(A, p, q);
    merge_sort(A, q + 1, r);
    merge(A, p, q, r);
}

//void p_merge_sort(std::vector<int>& A, const unsigned int p, const unsigned int r) {
void p_merge_sort(concurrency::concurrent_vector<int>& A, const unsigned int p, const unsigned int r) {
    // page 39 CLRS
    if (p >= r) return;
    if ((r - p) < 128) {
        std::sort(&A[p], &A[r]);
        return;
    }

    auto q = (p + r) >> 1;
    auto f1 = [&A, p, q] {p_merge_sort(A, p, q);};
    auto f2 = [&A, q, r] {p_merge_sort(A, q + 1, r);};

    concurrency::parallel_invoke(f1,f2);
  
    // P_merge(A, p, q, r);  currently this is slower than sequential merge.
     merge(A, p, q, r);

}


int main()
{
    
    auto random_integer = []() {
        std::random_device rd;     // Only used once to initialise (seed) engine
        std::mt19937 rng(rd());    // Random-number engine used (Mersenne-Twister in this case)
        std::uniform_int_distribution<int> uni(0, 100); // Guaranteed unbiased
        return uni(rng);};


    int N = 1 << 20;
   // std::vector<int> v(N);
    concurrency::concurrent_vector<int> v(N);
    
    std::generate(v.begin(), v.end(), random_integer);
   
    auto start_time = std::chrono::high_resolution_clock::now();
    merge_sort(v, 0, N - 1);
    auto end_time = std::chrono::high_resolution_clock::now();
    auto time = end_time - start_time;
    std::cout << "Size  " << N << "sequential took " <<
        time / std::chrono::microseconds(1) << " micros to run.\n";

    std::generate(v.begin(), v.end(), random_integer);
   // std::cout << "\nunsorted v" << v;
     start_time = std::chrono::high_resolution_clock::now();
    p_merge_sort(v, 0, N-1);
     end_time = std::chrono::high_resolution_clock::now();
      time = end_time - start_time;
    std::cout << "Size  " << N << "parallel took " <<
        time / std::chrono::microseconds(1) << " micros to run.\n";
  //  std::cout << "\nsorted v";
  //  for (auto el : v) { std::cout << el << ","; }
    std::generate(v.begin(), v.end(), random_integer);
    start_time = std::chrono::high_resolution_clock::now();
    std::sort(std::execution::par_unseq,v.begin(), v.end());
    end_time = std::chrono::high_resolution_clock::now();
    time = end_time - start_time;
    std::cout << "Size  " << N << "std:sort parallel took " <<
        time / std::chrono::microseconds(1) << " micros to run.\n";
    std::generate(v.begin(), v.end(), random_integer);
    start_time = std::chrono::high_resolution_clock::now();
    std::sort( v.begin(), v.end());
    end_time = std::chrono::high_resolution_clock::now();
    time = end_time - start_time;
    std::cout << "Size  " << N << "std:sort sequential  took " <<
        time / std::chrono::microseconds(1) << " micros to run.\n";
   

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
